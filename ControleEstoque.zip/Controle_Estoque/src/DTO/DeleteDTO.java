/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

/**
 *
 * @author Lucas
 */
public class DeleteDTO {
    private String codigo_del;

    /**
     * @return the codigo_del
     */
    public String getCodigo_del() {
        return codigo_del;
    }

    /**
     * @param codigo_del the codigo_del to set
     */
    public void setCodigo_del(String codigo_del) {
        this.codigo_del = codigo_del;
    }
}
