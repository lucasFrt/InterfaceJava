/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhobuild1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lucas
 */
public class Produtosdao {
    
    Connection conn;
    
    public ResultSet autenticarAdcionar(produtosdto objprodutosdto) throws SQLException, ClassNotFoundException{
        conn = conexaBanco.getConnection();
        
        try {
            String  sql = "INSERT INTO produtos(nome_produtos, descrição, qtd )VALUES(?, ?, ?)";
            PreparedStatement pstm = conn.prepareStatement(sql);
            
            pstm.setString(1, objprodutosdto.getNome_produto());
            pstm.setString(2, objprodutosdto.getDescricao());
            pstm.setString(3, objprodutosdto.getQuantidade());
            
            ResultSet rs = pstm.executeQuery();
            return rs;
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "produtosDAO: " + erro);
            return null;
            
        }
    }
    
}