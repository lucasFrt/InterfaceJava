
package trabalhobuild1;

import javax.swing.JTextArea;
import javax.swing.JTextField;

public class produtosdto {
    //private Integer id;
    private int id_produto;
    private String nome_produto;
    private String quantidade;
    private String descricao;
    //MÉTODO CONSTRUTOR CHEIO
    public produtosdto(Integer id_produto , String nome_produto, String quantidade, String descricao) {
    //public Cliente(Integer id, String nome, String idade, String rg) {    
        //this.id=id;
        this.id_produto = id_produto;
        this.nome_produto = nome_produto;
        this.quantidade = quantidade;
        this.descricao = descricao;
       // this.rg = rg;
    }
    //MÉTODO CONSTRUTOR VAZIO
    public produtosdto() {
    }

    public int getId_produto() {
        return id_produto;
    }

    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }

    public String getNome_produto() {
        return nome_produto;
    }

    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    void setNome_produto(JTextField textnome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setQuantidade(JTextField textqtd) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setDescricao(JTextArea textdesc) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

  
